import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api';

@Component({
  standalone: true,
  selector: 'app-email-notification',
  imports: [CommonModule],
  templateUrl: './email-notification.html'
})
export class EmailNotification {

  success = false;
  error = false;

  constructor(private api: ApiService) {}

  send() {
    this.api.sendNotification().subscribe({
      next: () => this.success = true,
      error: () => this.error = true
    });
  }
}
