import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api';

@Component({
  standalone: true,
  selector: 'app-reservation-create',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './reservation-create.html'
})
export class ReservationCreate implements OnInit {

  form!: ReturnType<FormBuilder['group']>;
  success = false;
  error = false;

  constructor(
    private fb: FormBuilder,
    private api: ApiService,
    private route: ActivatedRoute
  ) {
    // ✅ initialize AFTER fb exists
    this.form = this.fb.group({
      employeeId: ['', Validators.required],
      itemId: ['', Validators.required],
      startDate: ['', Validators.required],
    });

this.form.get('startDate')?.addValidators(control => {
  if (!control.value) return null;

  const selected = new Date(control.value);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  return selected < today ? { pastDate: true } : null;
});

  }

  ngOnInit() {
    this.route.queryParamMap.subscribe(params => {
      const date = params.get('date');
      if (date) {
        this.form.patchValue({ startDate: date });
      }
    });
  }

  submit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.api.createReservation(this.form.value).subscribe({
      next: () => this.success = true,
      error: () => this.error = true
    });
  }
}
