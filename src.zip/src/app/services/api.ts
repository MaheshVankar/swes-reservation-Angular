import { Injectable } from '@angular/core';
import { of, delay } from 'rxjs';
import { EquipmentHistory } from '../models/equipment-history.model';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  getEquipmentHistory() {
    const data: EquipmentHistory[] = [
      {
        employeeName: 'John Doe',
        itemId: 'IT-001',
        itemType: 'Boots',
        status: 'Returned',
        date: '2025-01-05',
        returnDate: '2025-01-20'
      },
      {
        employeeName: 'Jane Smith',
        itemId: 'IT-002',
        itemType: 'Helmet',
        status: 'Pending',
        date: '2025-02-10'
      },
      {
        employeeName: 'Alex Brown',
        itemId: 'IT-003',
        itemType: 'Vest',
        status: 'Overdue',
        date: '2024-12-01'
      },
      {
        employeeName: 'Maria Garcia',
        itemId: 'IT-004',
        itemType: 'Boots',
        status: 'Returned',
        date: '2025-03-12',
        returnDate: '2025-03-25'
      }
    ];

    console.log('SERVICE DATA', data);

    return of(data).pipe(delay(500));
  }

  createReservation(payload: any) {
    return of(payload).pipe(delay(400));
  }

  sendNotification() {
    return of(true).pipe(delay(300));
  }
}
