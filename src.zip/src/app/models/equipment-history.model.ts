export interface EquipmentHistory {
  employeeName: string;
  itemId: string;
  itemType: string;
  status: 'Returned' | 'Pending' | 'Overdue';
  date: string;
  returnDate?: string;
}
