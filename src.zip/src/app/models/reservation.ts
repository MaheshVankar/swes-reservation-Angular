export interface Reservation {
}
