import { Component, ViewChild, TemplateRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { ApiService } from '../../services/api';
import { ActivatedRoute } from '@angular/router';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap'; // Import NgbModal and NgbModule
import { AvailabilityCalendar } from '../availability-calendar/availability-calendar';


@Component({
  standalone: true,
  selector: 'app-reservation-create',
  imports: [CommonModule, ReactiveFormsModule, NgbModule, AvailabilityCalendar], // Add NgbModule and AvailabilityCalendarView
  templateUrl: './reservation-create.html'
})

export class ReservationCreate {
  @ViewChild('calendarModalContent') calendarModalContent!: TemplateRef<any>; // Reference to ng-template

  form: FormGroup;
  calendarYear = new Date().getFullYear();
calendarMonth = new Date().getMonth() + 1;

onDateSelected(isoDate: string) {
  this.form.get('reservationDate')?.setValue(isoDate);
}
handleDateSelect(date: string) {
  this.form.get('reservationDate')?.setValue(date);
}


  loading = false;
  success = false;
  error: string | null = null;

  constructor(
    private fb: FormBuilder,
    private api: ApiService,
    private route: ActivatedRoute,
    private modalService: NgbModal // Inject NgbModal
  ) {
this.form = this.fb.group({
  employeeId: ['', Validators.required],
  item: ['', Validators.required],
  startDate: ['', [Validators.required, futureDateValidator]]
});
  }

  ngOnInit() {
  const date = this.route.snapshot.queryParamMap.get('date');
  if (date) {
    this.form.patchValue({ startDate: date });
  }
}

  openCalendarModal() {
    this.modalService.open(this.calendarModalContent, { ariaLabelledBy: 'calendar-modal-title', size: 'lg' }).result.then(
      (result) => {
        if (result) {
          this.form.controls['startDate'].setValue(result);
        }
      },
      (reason) => {
        // Modal dismissed (e.g., by clicking escape or backdrop)
        console.log(`Modal dismissed with: ${reason}`);
      }
    );
  }

onSubmit(): void {
  // Reset UI state on every submit
  this.error = null;
  this.success = false;

  // 🔴 THIS IS THE KEY FIX
  if (this.form.invalid) {
    this.form.markAllAsTouched();
    return;
  }

  this.loading = true;

  this.api.createReservation(this.form.value).subscribe({
    next: () => {
      this.loading = false;
      this.success = true;
      this.form.reset();
    },
    error: () => {
      this.loading = false;
      this.error = 'Failed to create reservation.';
    }
  });
}

}

export function futureDateValidator(control: AbstractControl): ValidationErrors | null {
  if (!control.value) return null;

  const selected = new Date(control.value);
  selected.setHours(0, 0, 0, 0);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  return selected > today ? null : { futureDate: true };
}
