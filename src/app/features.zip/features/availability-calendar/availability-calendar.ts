import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

interface CalendarDay {
  day: number;
  available: boolean;
}

@Component({
  selector: 'app-availability-calendar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './availability-calendar.html'
})
export class AvailabilityCalendar implements OnInit {

  @Input() year!: number;
  @Input() month!: number;

  @Output() daySelected = new EventEmitter<string>();

  days: CalendarDay[] = [];

  ngOnInit(): void {
    this.buildCalendar();
  }

  private buildCalendar(): void {
    const today = new Date();
    const todayMidnight = new Date(
      today.getFullYear(),
      today.getMonth(),
      today.getDate()
    );

    const daysInMonth = new Date(this.year, this.month, 0).getDate();
    this.days = [];

    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(this.year, this.month - 1, day);

      this.days.push({
        day,
        available: date >= todayMidnight
      });
    }
  }

  selectDay(day: CalendarDay): void {
    if (!day.available) {
      return; // HARD BLOCK
    }

    const formattedDate = `${this.year}-${String(this.month).padStart(2, '0')}-${String(day.day).padStart(2, '0')}`;
    this.daySelected.emit(formattedDate);
  }
}
